from django.urls import path
from . import  views

app_name = 'furn'

urlpatterns = [
    path('', views.home, name="home"),
    path('<int:pk>/details/', views.arrivals_detail, name='arrivals_detail'),
    path("signup/", views.signup, name='signup')
]
